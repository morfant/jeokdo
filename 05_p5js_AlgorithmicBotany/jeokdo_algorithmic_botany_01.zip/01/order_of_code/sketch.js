function setup() {
    createCanvas(400, 400);

    background(50);
    stroke(255);
    ellipse(200, 200, 100, 100);
    fill(0);
    rect(200, 200, 100, 100); // x, y 좌표를 변경하여 그려지는 위치를 이동
}